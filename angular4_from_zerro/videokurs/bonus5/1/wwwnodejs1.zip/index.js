var text = 'Hello world';

console.log(text);