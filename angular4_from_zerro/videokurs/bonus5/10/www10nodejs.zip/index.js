var optimist = require('optimist');

var message = optimist.argv.message;

console.log('Hello ' + message);